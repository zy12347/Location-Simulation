# A Survey on TOA Based Wireless Localization and NLOS Mitigation Techniques˙Ismail G ¨uvenc¸, Member, IEEE, and Chia-Chin Chong, Senior Member, IEEE

## overview

### type
conclude and evaluate different NLOS mitigation techniques

### background 
location based application is important in many different areas,such as advertisement, social network

### challenges 
precise and efficiency in NLOS scenarios
### possible solutions 
AOA(angle of arrival)

TOA(time of arrival) 

TDOA(time difference of arrival)

RSS(received-signal-strength techniques)
### drawbacks
no detailed investigation to improve performance

### two phase
![](./picture/model.png)
#### ranging
define:an action of estimating the distance between two nodes
#### Localization
define:an action of determining the exact location of an unknown
node from known nodes (anchors) by means of the intersection
of three or more measured ranges from known nodes
##### TOA
###### application 
celluar network
###### one-way-ranging 
perfect synchronization between TX(transmit) and RX(reveive)
###### two-way-ranging
does not require synchronization between TX and RX
##### TDOA
several RXs is used to reconstruct a TX’s position
###### application
wireless sensor networks
##### AOA
the distance between nodes is reconstructed from the angle between them
###### application
this technique is highly sensitive to multipath, NLOS conditions, and array precision
##### RSS
the distance is measured based on the attenuation introduced by the propagation of the signal from TX to RX.
###### application
its adoption is confined to applications that require coarse estimation
##### pattern machine based technique
fingerprint information of the measured radio signals at different geographical locations are utilized for position estimation
###### challenge
the fingerprint database may become unreliable, and may need to be updated frequently
### my puzzle
what is the advatange of TOA compared to other methods?
## mathematic
Applicants’ prior education should include the following prerequisites:

mathematics through vector calculus and differential equations,
calculus-based physics,
linear and non-linear circuits,
electromagnetics, and
signals and systems
Applicants whose prior education does not include the prerequisites listed above may still enroll under provisional status, followed by full admission status once they have completed the missing prerequisites. Missing prerequisites may be completed with Johns Hopkins Engineering (all prerequisites beyond calculus are available) or at another regionally accredited institution. Admitted students typically have earned a grade point average of at least 3.0 on a 4.0 scale (B or above) in the latter half of their undergraduate studies. Transcripts from all college studies must be submitted. When reviewing an application, the candidate’s academic and professional background will be considered.

The following is the profile of a typical successful applicant:

Grade point average of at least 3.7.
GRE scores of:
540 (156 on revised test) or above on the verbal reasoning part
770 (161 on revised test) or above on the quantitative reasoning part
5.0 or above on the analytical writing part
A TOEFL score of at least 100 (internet-based test) or 600 (paper-based test) and IELTS Academic Band Score equal to 7

Career Paths
Students who earn the master of science in computer engineering program gain a competitive edge over their peers, working in fields such as system design and specification; university teaching and research; sales; cost analysis; management; component design, research, and development; and consulting, production, and quality control.

Many graduates of the master of science in computer engineering program go on to further graduate study at PhD-granting institutions.
TOEFL: Internet-Based Test (IBT): Minimum Overall Required Score: 80
Minimum section requirements:
Reading: 19
Listening: 14
Speaking: 18 (23 is required to be considered for a teaching assistantship)
Writing: 22 (exceptions made for exceptional PhD applicants with financial support)
The following is the profile of a typical successful applicant:

Grade point average of at least 3.7.
GRE scores of:
540 (156 on revised test) or above on the verbal reasoning part
770 (161 on revised test) or above on the quantitative reasoning part
5.0 or above on the analytical writing part
A TOEFL score of at least 100 (internet-based test) or 600 (paper-based test) and IELTS Academic Band Score equal to 7'

分纯授课，项目，论文三种毕业模式

5个细分方向：
软件开发
硬件设计
数据分析和机器学习
量子计算
微电子学、光子学和纳米技术

TOEFL:  No min requirement. Avg admittee: >100 score; iBT: 90 minimum
9个方向：Architecture, Computer Systems, and Embedded Systems (ACSES)；bioECE；Decision, Information, and Communications；申请前要选好方向 Engineering (DICE)；Electromagnetics & Acoustics (EA)；Electronics, Photonics and Quantum Systems (EPQS)；Integrated Circuits & Systems (ICS)；Power Electronics and Power Systems (PEPS)；Software Engineering and Systems (SES)；

7个方向：Microelectronics, Photonics, and Nanotechnology
Integrated Circuits and Systems
Power and Energy Systems
Biomedical Imaging, Bioengineering and Acoustics
Electromagnetics, Optics, Remote Sensing
Signal Processing, Communications, Control Systems
Computing Systems, Networks, Software, and Algorithms

9个方向：Fields of Specialization (Bioe, Acoustics, Magnetic Res.)
Fields of Specialization (Communications)
Fields of Specialization (Computer Engineering)
Fields of Specialization (Control)
Fields of Specialization (Electromagnetics and Remote Sensing)
Fields of Specialization (Intergrated Circuits)
Fields of Specialization (Microelectronics and Quantum Electronics)
Fields of Specializatio (Power and Energy Systems)
Fields of Specialization (Signal Processing)

分纯授课，项目，论文三种毕业模式

5个细分方向：软件开发
硬件设计
数据分析和机器学习
量子计算
微电子学、光子学和纳米技术

9个细分方向：Specialization in Data-Driven Analysis and Computation

Specialization in Networking

Specialization in Wireless and Mobile Communications

Specialization in Integrated Circuits and Systems

Specialization in Smart Electric Energy

Specialization in Systems Biology and Neuroengineering

Specialization in Lightwave (Photonics) Engineering

Specialization in Microelectronic Devices

MS Research Specialization in Electrical Engineering

选课范围很广，覆盖以下范围：Bio-ECE and Digital Health
Computational and Cyberphysical Systems
Computer Communications and Networks
Cybersecurity
Data Science and Intelligent Systems
Hardware
Imaging and Optical Science
Mobile and Cloud Computing
Photonics, Electronics, and Nanotechnology
Sensing and Information
Signal Processing and Communications
Solid-State Circuits, Devices, and Materials
Software
Systems and Control