from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib import cm
import numpy as np
import random
import math
import NLOS
import LOS

class Analysis:

    def __init__(self, para):
        self.para={}
        self.para['BT'] = para['BT']
        self.para['BT_LOS'] = para['BT_LOS']
        self.para['BT_NLOS'] = para['BT_NLOS']
        self.para['lamda'], self.para['ave'], self.para['sigma'] = para['lamda'], para['ave'], para['sigma']
        self.para['MT_x'], self.para['MT_y'] = para['MT_x'], para['MT_y']

    def update(self):
        aml, lls1, lls_ave, lls_rs, ng, r_ls, lls_nlos, rwgh = 0,0,0,0,0,0,0,0
        Algo_Noise = {}
        for i, bt_para in enumerate(self.para['BT_LOS']):
            d=((self.para['MT_x'] - bt_para[0]) ** 2 + (self.para['MT_y'] - bt_para[1]) ** 2) ** 0.5
            n=math.log(d) * random.gauss(self.para['ave'], self.para['sigma'])
            self.para['BT_LOS'][i][2]=d+n

        for i, bt_para in enumerate(self.para['BT_NLOS']):
            d = ((self.para['MT_x'] - bt_para[0]) ** 2 + (self.para['MT_y'] - bt_para[1]) ** 2) ** 0.5
            n = math.log(d) * (self.para['lamda'] * np.random.exponential(self.para['lamda']) + random.gauss(self.para['ave'],self.para['sigma']))
            self.para['BT_NLOS'][i][2] = d + n

        self.para['BT'] = self.para['BT_LOS'] + self.para['BT_NLOS']

        aml_instance = LOS.Program(self.para['BT_LOS'])
        aml_x, aml_y = aml_instance.estimate()
        aml = ((aml_x - self.para['MT_x']) ** 2 + (aml_y - self.para['MT_y']) ** 2) ** 0.5
        lls1_instance = LOS.Program(self.para['BT_LOS'])
        lls1_x, lls1_y = lls1_instance.LLS_1_E()
        lls1 = ((lls1_x - self.para['MT_x']) ** 2 + (lls1_y - self.para['MT_y']) ** 2) ** 0.5
        lls_aver_instance = LOS.Program(self.para['BT_LOS'])
        lls_ave_x, lls_ave_y = lls_aver_instance.LLS_AVE_E()
        lls_ave = ((lls_ave_x - self.para['MT_x']) ** 2 + (lls_ave_y - self.para['MT_y']) ** 2) ** 0.5
        lls_rs_instance = LOS.Program(self.para['BT_LOS'])
        lls_rs_x, lls_rs_y = lls_rs_instance.LLS_RS_E()
        lls_rs = ((lls_rs_x - self.para['MT_x']) ** 2 + (lls_rs_y - self.para['MT_y']) ** 2) ** 0.5
        N_G_instance = LOS.Program(self.para['BT_LOS'])
        ng_pos = N_G_instance.NewTon_Gauss()
        ng_x, ng_y=ng_pos[-1][0], ng_pos[-1][1]
        ng = ((ng_x - self.para['MT_x']) ** 2 + (ng_y - self.para['MT_y']) ** 2) ** 0.5
        # s_ls_instance=LOS.Program(self.para['BT_LOS'])
        # r_ls_x, r_ls_y = s_ls_instance.R_LS_E()
        # r_ls = (r_ls_x-x)**2+(r_ls_y-y)**2
        '''
        lls_nlos_instance = NLOS.Program(self.para['BT'])
        lls_nlos_x, lls_nlos_y = lls_nlos_instance.LLS_NLOS()
        lls_nlos = ((lls_nlos_x - self.para['MT_x']) ** 2 + (lls_nlos_y - self.para['MT_y']) ** 2) ** 0.5
        rwgh_instance = NLOS.Program(self.para['BT'])
        NLOS_pos, rwgh_pos = rwgh_instance.RSWG()
        rwgh_x, rwgh_y = rwgh_pos[0], rwgh_pos[1]
        rwgh = ((rwgh_x - self.para['MT_x']) ** 2 + (rwgh_y - self.para['MT_y']) ** 2) ** 0.5
        '''
        Algo_Noise = {'AML': aml, 'LLS1':lls1, 'LLS_AVE':lls_ave, 'LLS_RS': lls_rs, 'Newton': ng}
        return Algo_Noise

    def Change_Noise(self):
        aml, lls1, lls_ave, lls_rs, ng, sigma = [], [], [], [], [], []
        count, skip = 20, 1
        for i in range(count):
            print('1')
            self.para['sigma'] = skip * i
            sigma.append(skip * i)
            aml1, lls11, lls_ave1, lls_rs1, ng1= [], [], [], [], []
            for i in range(10):
                x = random.random() * 800
                y = random.random() * 600
                self.para['MT_x'], self.para['MT_y'] = x, y
                Noise = self.update()
                aml1.append(Noise['AML'])
                lls11.append(Noise['LLS1'])
                lls_ave1.append(Noise['LLS_AVE'])
                lls_rs1.append(Noise['LLS_RS'])
                ng1.append(Noise['Newton'])
            bias = {'AML': sum(aml1) / count, 'LLS1': sum(lls11) / count, 'LLS_AVE': sum(lls_ave1) / count, 'LLS_RS': sum(lls_rs1) / count, 'Newton': sum(ng1) / count}
            aml.append(bias['AML'])
            lls1.append(bias['LLS1'])
            lls_ave.append(bias['LLS_AVE'])
            lls_rs.append(bias['LLS_RS'])
            ng.append(bias['Newton'])

        plt.plot(sigma, aml, label='AML')
        plt.plot(sigma, lls1, label='LLS1')
        plt.plot(sigma, lls_ave, label='LLS_AVE')
        plt.plot(sigma, lls_rs, label='LLS_RS')
        plt.plot(sigma, ng, label='Newton')
        plt.xlabel('Gauss_Noise')
        plt.ylabel('Average_Bias')
        plt.title('Change Noise')
        plt.legend()
        plt.show()

    def Change_MT_Pos(self):
        aml, lls1, lls_ave, lls_rs, ng, r_ls, lls_nlos, rwgh = [], [], [], [], [], [], [], []
        count = 10
        for i in range(count):
            print('1')
            x = random.random() * 800
            y = random.random() * 600
            self.para['MT_x'], self.para['MT_y'] = x, y
            Noise = self.update()
            aml.append(Noise['AML'])
            lls1.append(Noise['LLS1'])
            lls_ave.append(Noise['LLS_AVE'])
            lls_rs.append(Noise['LLS_RS'])
            ng.append(Noise['Newton'])
            #r_ls.append(Noise['R_LS'])
            #lls_nlos.append(Noise['LLS_NLOS'])
            #rwgh.append(Noise['RWGH'])

        bias = [sum(aml) / count, sum(lls1) / count, sum(lls_ave) / count, sum(lls_rs) / count, sum(ng) / count]
        name = ['AML', 'LLS1', 'LLS_AVE', 'LLS_RS', 'N_G']
        plt.bar(range(len(bias)), bias, tick_label=name)
        plt.xlabel('Algorihm')
        plt.ylabel('Average_Bias')
        plt.title('Change MT')
        plt.show()

    def Bt_pos(self):
        print('hello')

    def Heatmap(self):
        datas1, datas2 = [], []
        for i in range(20):
            data1, data2 = [], []
            self.para['MT_x'] = 200+25*i
            for j in range(20):
                self.para['MT_y'] =50+25*j
                for i, bt_para in enumerate(self.para['BT_LOS']):
                    d = ((self.para['MT_x'] - bt_para[0]) ** 2 + (self.para['MT_y'] - bt_para[1]) ** 2) ** 0.5
                    n = math.log(d+1) * random.gauss(self.para['ave'], self.para['sigma'])
                    self.para['BT_LOS'][i][2] = d + n
                lls1_instance = LOS.Program(self.para['BT_LOS'])

                lls1_x, lls1_y = lls1_instance.LLS_1_E()
                noise1 = ((lls1_x - self.para['MT_x']) ** 2 + (lls1_y - self.para['MT_y']) ** 2)

                data1.append(noise1)
            datas1.append(data1)

        x_tick=[225+50*i for i in range(10)]
        y_tick=[75+50*i for i in range(10)]
        ax1=plt.subplot()
        im1=ax1.imshow(datas1,cmap=cm.binary)
        ax1.set_xticks(np.arange(0.5,20.5,2), labels=x_tick)
        ax1.set_yticks(np.arange(0.5,20.5,2), labels=y_tick)
        plt.title('Heat Map')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.colorbar(im1)
        plt.show()

    def plot3D(self):
        figure = plt.figure()
        ax = Axes3D(figure)
        X = np.arange(0, 1000, 10)
        Y = np.arange(0, 600, 10)
        X, Y = np.meshgrid(X, Y)
        Z = sum([(self.para['BT_LOS'][i][2]-((self.para['BT_LOS'][i][0]-X)**2+(self.para['BT_LOS'][i][1]- Y)**2)**0.5)**2 for i in range(len(self.para['BT_LOS']))])
        ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap='rainbow')
        ax.text(self.para['MT_x'],self.para['MT_y'],20,"MT")
        plt.title('3D')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.show()

def plot_cicle(centers,rads,MT,BT_x,BT_y):
    fig=plt.figure()
    ax = fig.add_subplot(111)
    i=0
    for center,rad in zip(centers,rads):
        cir=plt.Circle((center[0],center[1]),radius=rad,color='y',fill=False)
        plt.plot([center[0], MT[0]], [center[1], MT[1]])
        plt.text((center[0]+MT[0])/2-5,(center[1]+MT[1])/2+8,'d'+str(i))
        ax.add_patch(cir)
        i=i+1
    plt.plot([centers[0][0] - rads[0], centers[0][0]], [centers[0][1], centers[0][1]])
    plt.text((centers[0][0] - rads[0] + centers[0][0]) / 2, (centers[0][1] + centers[0][1]) / 2 + 5, 'd0' + '\'')

    plt.plot([centers[1][0], centers[1][0]], [centers[1][1]-rads[1], centers[1][1]])
    plt.text((centers[1][0] + centers[1][0]) / 2+5, (centers[1][1]-rads[1] + centers[1][1]) / 2, 'd1' + '\'')

    plt.plot([centers[2][0], centers[2][0]], [centers[2][1] +rads[2], centers[2][1]])
    plt.text((centers[2][0] + centers[2][0]) / 2 + 5, (centers[2][1] +rads[2] + centers[1][1]) / 2, 'd2' + '\'')

    l3,=ax.plot(BT_x,BT_y,'bs')
    l1,=ax.plot(MT[0],MT[1],'ro')
    l2,=ax.plot(390,290,'k*')
    plt.legend(handles=[l1, l2,l3], labels=['true position', 'estimate','base station'], loc='best')
    plt.axis('equal')
    plt.axis('off')
    plt.show()

def main():
    print('hello')
    ana = Analysis()
    ana.Change_MT_Pos()

if __name__=='__main__':
    main()