from tkinter import *
import random
#from turtle import *
import tkinter.messagebox as messagebox

class simulation:

    def __init__(self,master=None):
        self.root=master
        self.root.geometry('800x600')
        self.root.title('SIMULATION')
        self.Home()

    def Home(self):
        self.Home1 = Frame(self.root)
        self.Home2 = Frame(self.root)
        self.Home3 = Frame(self.root)

        menu = Menu(self.root)
        self.root.config(menu=menu)

        filemenu = Menu(menu)
        menu.add_cascade(label='TOA', menu=filemenu)
        filemenu.add_command(label='1', command=self.createPage1)
        filemenu.add_command(label='2', command=self.createPage2)

        self.Home1.config(bg='black',height=600,width=800)
        Button(self.Home1,text="TOA").place(x=400,y=300)
        self.Home1.place(x=0,y=0)

    def createPage2(self):
        self.frame2_1 = Frame(self.root)
        self.frame2_2 = Frame(self.root)
        self.frame2_3 = Frame(self.root)

        self.frame2_1.config(bg='white', height=600, width=800)
        Label(self.frame2_1, text='frame1').place(in_=self.frame2_1, anchor=NW)
        self.frame2_1.place(x=0, y=0)

    def createPage1(self):
        self.frame1 = Frame(self.root)
        self.frame2 = Frame(self.root)
        self.frame3 = Frame(self.root)

        self.frame1.config(bg='white',height=500,width=600)
        Label(self.frame1,text='frame1').place(in_=self.frame1,anchor=NW)
        self.frame1.place(x=0,y=0)

        self.frame2.config(bg='#334353', height=500, width=200)
        Label(self.frame2, text='frame2').place(in_=self.frame2, anchor=NW)
        self.frame2.place(x=600, y=0)

        self.frame3.config(bg='#EEE8AA', height=100, width=800)
        Label(self.frame3, text='frame3').place(in_=self.frame3, anchor=NW)
        self.frame3.place(x=0, y=500)

#if __name__=='main':
def main():
    root=Tk()
    simulation(root)
    mainloop()

main()
